"""Top-level package for JUtils."""

__author__ = """Jose Miguel Millán"""
__email__ = 'jevo160296@gmail.com'
__version__ = '0.1.0'
